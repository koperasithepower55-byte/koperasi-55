# 📘 TUTORIAL DEPLOY — LANGKAH DEMI LANGKAH
## Koperasi The Power 55 · Untuk Pemula · Windows · Tanpa Install Apapun

---

## ✅ YANG PERLU ANDA SIAPKAN

- Komputer Windows + browser (Chrome / Edge)
- Email aktif (untuk daftar 3 layanan gratis)
- Waktu sekitar **2–3 jam**
- File-file dari folder `koperasi-app` (sudah saya siapkan)

**Anda TIDAK perlu:** install Node.js, buka Command Prompt, mengetik kode, atau paham pemrograman.

---

## 🗺️ PETA PERJALANAN

```
TAHAP 1 (30 mnt) → Buat database di Supabase
TAHAP 2 (20 mnt) → Upload file ke GitHub
TAHAP 3 (15 mnt) → Deploy ke Vercel → aplikasi LIVE
TAHAP 4 (20 mnt) → Bagikan ke anggota
```

---

# TAHAP 1 — DATABASE (SUPABASE)

Supabase = tempat menyimpan semua data koperasi. Gratis.

### Langkah 1.1 — Daftar

1. Buka browser, ketik: **supabase.com**
2. Klik tombol hijau **"Start your project"** (pojok kanan atas)
3. Klik **"Continue with GitHub"** — kalau belum punya GitHub, klik **"Sign up with Email"** saja
4. Isi email + password → cek email Anda → klik link konfirmasi

### Langkah 1.2 — Buat Project

1. Setelah masuk, klik tombol hijau **"New project"**
2. Isi form:
   - **Name:** `koperasi-55`
   - **Database Password:** buat password baru, **CATAT DI TEMPAT AMAN** (contoh: `Koperasi55Aman`)
   - **Region:** pilih **Southeast Asia (Singapore)**
3. Klik **"Create new project"**
4. ⏳ **Tunggu 2–3 menit** sampai selesai (ada loading bar)

### Langkah 1.3 — Isi Database

1. Di menu kiri, cari ikon **`</>`** bernama **"SQL Editor"** → klik
2. Klik **"+ New query"**
3. Buka file **`SUPABASE_SETUP.sql`** (dari folder yang saya kirim) pakai Notepad
4. **Tekan Ctrl+A** (pilih semua) lalu **Ctrl+C** (copy)
5. Kembali ke browser, klik di kotak putih besar, tekan **Ctrl+V** (paste)
6. Klik tombol hijau **"Run"** di kanan bawah (atau tekan Ctrl+Enter)
7. ✅ Kalau muncul tulisan **"Success. No rows returned"** → BERHASIL

**Cek hasilnya:**
- Menu kiri → klik **"Table Editor"**
- Harus muncul 6 tabel: `members`, `loans`, `applications`, `votes`, `banks`, `transactions`
- Klik `members` → harus ada 25 baris (24 anggota + 1 pengurus)

### Langkah 1.4 — Ambil Kunci Akses (PENTING!)

1. Menu kiri paling bawah → klik ikon **gerigi ⚙️ "Project Settings"**
2. Klik **"API"** (menu sebelah kiri dalam settings)
3. Anda akan lihat 2 hal penting. **Copy ke Notepad**, simpan:

   **a. Project URL** — bentuknya seperti:
   ```
   https://abcdefghijk.supabase.co
   ```

   **b. anon public key** — teks panjang mulai dengan `eyJhbGci...`
   (klik tombol **Copy** di sebelahnya)

📌 **Simpan dua-duanya di Notepad.** Nanti dipakai di Tahap 3.

---

# TAHAP 2 — UPLOAD FILE (GITHUB)

GitHub = tempat menyimpan kode aplikasi. Gratis.

### Langkah 2.1 — Daftar GitHub

1. Buka **github.com**
2. Klik **"Sign up"**
3. Isi email, password, username (contoh: `ahmadalif55`)
4. Verifikasi email

### Langkah 2.2 — Buat Repository

1. Setelah login, klik tombol **"+"** di kanan atas → **"New repository"**
2. Isi:
   - **Repository name:** `koperasi-55`
   - Pilih **Public** (gratis)
   - **JANGAN** centang "Add a README file"
3. Klik **"Create repository"**

### Langkah 2.3 — Upload File

Halaman berikutnya akan muncul tulisan "Quick setup". Cari link biru bertuliskan **"uploading an existing file"** → klik.

Sekarang bagian penting — **cara upload folder**:

1. Buka **File Explorer** di Windows, masuk ke folder `koperasi-app`
2. Anda akan lihat isi seperti ini:
   ```
   koperasi-app/
   ├── src/              ← FOLDER
   │   ├── App.jsx
   │   ├── main.jsx
   │   └── supabase.js
   ├── index.html
   ├── package.json
   ├── vite.config.js
   └── .gitignore
   ```
3. **Pilih SEMUA isi folder** (Ctrl+A) — termasuk folder `src`
4. **Drag (seret)** semuanya ke area kotak-kotak di halaman GitHub
5. Tunggu semua file muncul di daftar
6. Scroll ke bawah → di kotak "Commit changes" tulis: `Upload aplikasi koperasi`
7. Klik tombol hijau **"Commit changes"**

✅ Sekarang halaman repository Anda harus menampilkan file-file tadi.

> **⚠️ Kalau folder `src` tidak ikut ter-upload:** upload file di root dulu (index.html, package.json, vite.config.js). Lalu klik **"Add file" → "Create new file"**, ketik di kolom nama: `src/App.jsx` (tanda `/` otomatis membuat folder), lalu paste isi file App.jsx, klik Commit. Ulangi untuk `src/main.jsx` dan `src/supabase.js`.

---

# TAHAP 3 — DEPLOY (VERCEL)

Vercel = yang membuat aplikasi bisa diakses lewat internet. Gratis.

### Langkah 3.1 — Daftar Vercel

1. Buka **vercel.com**
2. Klik **"Sign Up"**
3. Klik **"Continue with GitHub"** → klik **"Authorize Vercel"**

### Langkah 3.2 — Import Project

1. Di dashboard Vercel, klik **"Add New..."** → **"Project"**
2. Cari `koperasi-55` di daftar → klik **"Import"**

### Langkah 3.3 — Masukkan Kunci Supabase (JANGAN DILEWAT!)

Di halaman konfigurasi, cari bagian **"Environment Variables"** → klik untuk membuka.

Masukkan **2 variabel**:

**Variabel pertama:**
- Kolom **Key** (atau Name): ketik `VITE_SUPABASE_URL`
- Kolom **Value**: paste Project URL dari Tahap 1.4
- Klik **"Add"**

**Variabel kedua:**
- Kolom **Key**: ketik `VITE_SUPABASE_ANON_KEY`
- Kolom **Value**: paste anon public key dari Tahap 1.4
- Klik **"Add"**

> ⚠️ Penulisan harus **PERSIS** seperti di atas — huruf besar semua, pakai garis bawah `_`, tidak ada spasi.

### Langkah 3.4 — Deploy

1. Klik tombol hitam **"Deploy"**
2. ⏳ Tunggu 1–2 menit (muncul animasi)
3. 🎉 Kalau muncul konfeti dan tulisan **"Congratulations!"** → **APLIKASI ANDA SUDAH LIVE**

### Langkah 3.5 — Dapatkan Alamat Aplikasi

1. Klik **"Continue to Dashboard"**
2. Di bagian atas ada alamat seperti: **`koperasi-55.vercel.app`**
3. Klik untuk membuka → aplikasi Anda muncul!

### Langkah 3.6 — Tes Login

Coba login sebagai pengurus:
- **Nomor Anggota:** `0`
- **PIN:** `5555`

Kalau masuk ke Dashboard Pengurus → **SEMUA BERHASIL** ✅

---

# TAHAP 4 — SIAPKAN UNTUK ANGGOTA

### Langkah 4.1 — Ganti PIN Pengurus

PIN `5555` terlalu mudah ditebak. Ganti sekarang:

1. Buka Supabase → **Table Editor** → tabel **`members`**
2. Cari baris dengan `no = 0` (Pengurus)
3. Klik kolom **`pin`** → ganti `5555` jadi PIN rahasia Anda (contoh: `8291`)
4. Tekan **Enter** untuk menyimpan

### Langkah 4.2 — Catat PIN Setiap Anggota

Setiap anggota punya PIN default. Buka Table Editor → `members` untuk melihat.

Pola default: **1000 + nomor anggota**

| Nama | No. Anggota | PIN |
|---|---|---|
| M. Rizal Fanani | 1 | 1001 |
| Ahmad Alif M. | 3 | 1003 |
| Yudha Setiawan | 6 | 1006 |
| Ghufron | 10 | 1010 |
| … | … | … |
| Agus Setyawan | 24 | 1024 |

Anda bisa mengganti PIN anggota lewat aplikasi: **Tab Anggota → klik ✏️ di kartu anggota**.

### Langkah 4.3 — Perbaiki Data Awal

Beberapa angka masih perkiraan. Sebelum dibagikan, rapikan dulu:

1. Login sebagai pengurus
2. **Tab Pembukuan → Saldo Bank** → klik kartu BRI → isi saldo asli sesuai rekening koran
3. **Tab Anggota** → klik ✏️ di setiap anggota → sesuaikan:
   - Tabungan Wajib per bulan
   - Total Tabungan Wajib yang sudah disetor
   - SHU akumulasi
4. **Tab Pinjaman** → cek sisa pinjaman sudah benar

### Langkah 4.4 — Kirim ke Grup WhatsApp

Contoh pesan:

```
📱 APLIKASI KOPERASI THE POWER 55 SUDAH JADI

Link: https://koperasi-55.vercel.app

Cara masuk:
1. Buka link di atas dari HP
2. Nomor Anggota: (lihat daftar di bawah)
3. PIN: 1000 + nomor anggota Anda
   Contoh: anggota no. 6 → PIN 1006

Di dalam aplikasi Anda bisa:
✅ Lihat tabungan wajib & tunggakan
✅ Lihat sisa pinjaman & jadwal cicilan
✅ Lihat SHU yang sudah diterima
✅ Ajukan pinjaman / jasa sertifikat
✅ Voting pengajuan anggota lain

Tips: buka di Chrome → menu titik tiga →
"Tambahkan ke layar utama" supaya jadi
seperti aplikasi biasa.

Ada kendala? Hubungi pengurus.
```

---

# 🔧 CARA MENGUBAH APLIKASI NANTI

### Ubah data (anggota, saldo, pinjaman)
Langsung dari **dalam aplikasi** (login sebagai pengurus). Tidak perlu sentuh GitHub.

### Ubah tampilan atau menu
1. Buka GitHub → repository `koperasi-55` → folder `src` → klik `App.jsx`
2. Klik ikon **pensil ✏️** di kanan atas
3. Edit, lalu scroll ke bawah → **"Commit changes"**
4. Vercel otomatis update dalam ~1 menit

### Tambah anggota baru
Supabase → Table Editor → `members` → **"+ Insert row"** → isi `no`, `name`, `pin`, `join_year`, `sw_rate`, `status`.

---

# ❗ KALAU ADA MASALAH

| Gejala | Penyebab | Solusi |
|---|---|---|
| Layar merah "Gagal memuat data" | Environment Variables salah | Vercel → Settings → Environment Variables → periksa penulisan → **Deployments → titik tiga → Redeploy** |
| Deploy gagal / "Build failed" | Ada file yang tidak ter-upload | Cek GitHub: harus ada `package.json`, `index.html`, `vite.config.js`, dan folder `src` berisi 3 file |
| Login selalu ditolak | Nomor/PIN salah | Cek di Supabase → Table Editor → `members` |
| Halaman kosong putih | Cache browser | Tekan **Ctrl+Shift+R** |
| Saldo bank tidak berubah | Transaksi belum dipilih rekeningnya | Saat catat transaksi, pastikan rekening terpilih |

**Cara paling ampuh:** di Vercel → tab **Deployments** → klik titik tiga di deployment terakhir → **"Redeploy"**.

---

# 💰 BIAYA

| Layanan | Paket | Biaya |
|---|---|---|
| Supabase | Free | **Rp 0** (cukup untuk ratusan anggota) |
| GitHub | Free | **Rp 0** |
| Vercel | Hobby | **Rp 0** |
| Domain sendiri (opsional) | .com | ~Rp 200rb/tahun |

**Total: Rp 0/bulan.**

⚠️ **Catatan penting:** project Supabase gratis akan **dijeda otomatis** kalau tidak ada aktivitas selama **7 hari**. Selama ada anggota yang membuka aplikasi setiap minggu, aman. Kalau terlanjur terjeda: login ke supabase.com → klik **"Restore project"**.

---

# 🔐 CATATAN KEAMANAN

Pengaturan sekarang cocok untuk koperasi kecil yang saling kenal, tapi perlu Anda ketahui:

1. **PIN disimpan apa adanya** (belum dienkripsi). Jangan pakai PIN yang sama dengan PIN ATM.
2. **Ganti PIN default** semua anggota setelah mereka login pertama kali.
3. **Jangan share** `service_role key` dari Supabase ke siapa pun — yang boleh dipakai hanya `anon public key`.
4. Kalau nanti anggota bertambah banyak (>50) atau menyimpan data lebih sensitif, sebaiknya minta bantuan developer untuk memperketat aturan keamanan (Row Level Security).

---

# ✅ CHECKLIST

- [ ] Akun Supabase dibuat, project `koperasi-55` jalan
- [ ] SQL dijalankan, 6 tabel muncul
- [ ] Project URL + anon key sudah dicatat
- [ ] Akun GitHub dibuat, repository `koperasi-55` berisi semua file
- [ ] Vercel terhubung, 2 Environment Variables terisi
- [ ] Deploy berhasil, dapat alamat `.vercel.app`
- [ ] Login pengurus (no 0) berhasil
- [ ] PIN pengurus sudah diganti
- [ ] Saldo bank & data anggota sudah dirapikan
- [ ] Link dibagikan ke grup WhatsApp

---

## 🎯 SETELAH LIVE

**Minggu pertama:** ajak 2–3 anggota mencoba dulu (Yudha, Ghufron, Sandi misalnya). Minta mereka login, lihat akun, coba ajukan pinjaman kecil. Perbaiki apa yang membingungkan.

**Minggu kedua:** bagikan ke semua anggota. Sediakan diri untuk membantu yang kesulitan login.

**Bulan pertama:** jalankan dua sistem berdampingan — aplikasi **dan** catatan manual/WhatsApp. Kalau angkanya cocok selama sebulan, baru tinggalkan cara lama sepenuhnya.

---

*Tutorial ini bisa dicetak. Simpan sebagai pegangan pengurus.*
