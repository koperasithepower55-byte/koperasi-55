-- ═══════════════════════════════════════════════════════════
-- KOPERASI THE POWER 55 — DATABASE SETUP
-- Copy SELURUH isi file ini, paste ke Supabase SQL Editor, klik RUN
-- ═══════════════════════════════════════════════════════════

-- ─── 1. HAPUS TABEL LAMA (kalau ada) ───
DROP TABLE IF EXISTS votes CASCADE;
DROP TABLE IF EXISTS applications CASCADE;
DROP TABLE IF EXISTS transactions CASCADE;
DROP TABLE IF EXISTS loans CASCADE;
DROP TABLE IF EXISTS banks CASCADE;
DROP TABLE IF EXISTS members CASCADE;

-- ─── 2. BUAT TABEL ───

CREATE TABLE members (
  no            INTEGER PRIMARY KEY,
  name          TEXT NOT NULL,
  join_year     INTEGER DEFAULT 2019,
  join_month    INTEGER DEFAULT 1,
  sw_rate       INTEGER DEFAULT 10000,
  sw_paid       INTEGER DEFAULT 0,
  shu_total     INTEGER DEFAULT 0,
  completed_loans INTEGER DEFAULT 0,
  status        TEXT DEFAULT 'aktif',
  pin           TEXT NOT NULL,
  phone         TEXT,
  is_admin      BOOLEAN DEFAULT FALSE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE loans (
  id          SERIAL PRIMARY KEY,
  member_no   INTEGER REFERENCES members(no) ON DELETE CASCADE,
  amount      INTEGER NOT NULL,
  tenor       INTEGER NOT NULL DEFAULT 3,
  status      TEXT DEFAULT 'cicil',
  start_date  DATE,
  sisa        INTEGER DEFAULT 0,
  last_pay    DATE,
  lunas_date  DATE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE applications (
  id            SERIAL PRIMARY KEY,
  applicant_no  INTEGER REFERENCES members(no) ON DELETE CASCADE,
  type          TEXT NOT NULL,
  amount        INTEGER NOT NULL,
  tenor         INTEGER NOT NULL,
  purpose       TEXT,
  cert_type     TEXT,
  provider      TEXT,
  status        TEXT DEFAULT 'voting',
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  deadline      TIMESTAMPTZ NOT NULL,
  decided_at    TIMESTAMPTZ
);

CREATE TABLE votes (
  id              SERIAL PRIMARY KEY,
  application_id  INTEGER REFERENCES applications(id) ON DELETE CASCADE,
  voter_no        INTEGER REFERENCES members(no) ON DELETE CASCADE,
  vote            TEXT NOT NULL,
  voted_at        TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(application_id, voter_no)
);

CREATE TABLE banks (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT DEFAULT 'bank',
  holder      TEXT,
  acc_no      TEXT DEFAULT '-',
  balance     BIGINT DEFAULT 0,
  color       TEXT DEFAULT '#0D7377',
  last_update TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE transactions (
  id          SERIAL PRIMARY KEY,
  date        DATE NOT NULL,
  type        TEXT NOT NULL,
  category    TEXT NOT NULL,
  amount      BIGINT NOT NULL,
  bank_id     INTEGER REFERENCES banks(id) ON DELETE SET NULL,
  member_no   INTEGER REFERENCES members(no) ON DELETE SET NULL,
  description TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ─── 3. TRIGGER: saldo bank otomatis update ───

CREATE OR REPLACE FUNCTION apply_tx_to_bank() RETURNS TRIGGER AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    IF NEW.bank_id IS NOT NULL THEN
      UPDATE banks SET balance = balance + (CASE WHEN NEW.type='in' THEN NEW.amount ELSE -NEW.amount END),
                       last_update = NOW()
      WHERE id = NEW.bank_id;
    END IF;
    RETURN NEW;
  ELSIF (TG_OP = 'DELETE') THEN
    IF OLD.bank_id IS NOT NULL THEN
      UPDATE banks SET balance = balance - (CASE WHEN OLD.type='in' THEN OLD.amount ELSE -OLD.amount END),
                       last_update = NOW()
      WHERE id = OLD.bank_id;
    END IF;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tx_insert AFTER INSERT ON transactions
FOR EACH ROW EXECUTE FUNCTION apply_tx_to_bank();

CREATE TRIGGER trg_tx_delete AFTER DELETE ON transactions
FOR EACH ROW EXECUTE FUNCTION apply_tx_to_bank();

-- ─── 4. KEAMANAN (RLS) ───
-- Mode sederhana: aplikasi memakai satu anon key, akses diatur di aplikasi.
-- Untuk koperasi kecil ini sudah memadai. Bisa diperketat nanti.

ALTER TABLE members       ENABLE ROW LEVEL SECURITY;
ALTER TABLE loans         ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications  ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes         ENABLE ROW LEVEL SECURITY;
ALTER TABLE banks         ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions  ENABLE ROW LEVEL SECURITY;

CREATE POLICY p_members ON members FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY p_loans ON loans FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY p_apps ON applications FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY p_votes ON votes FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY p_banks ON banks FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY p_tx ON transactions FOR ALL USING (true) WITH CHECK (true);

-- ─── 5. DATA ANGGOTA ───
-- PIN default = 4 digit. GANTI setelah anggota login pertama kali!

INSERT INTO members (no, name, join_year, join_month, sw_rate, sw_paid, shu_total, completed_loans, status, pin, is_admin) VALUES
  (0,  'Pengurus',           2019, 11, 0,     0,       0,       0, 'aktif',     '5555', TRUE),
  (1,  'M. Rizal Fanani',    2019, 11, 20000, 1100000, 1930000, 2, 'aktif',     '1001', FALSE),
  (2,  'Subangun Pola',      2019, 11, 10000, 550000,  1930000, 1, 'aktif',     '1002', FALSE),
  (3,  'Ahmad Alif M.',      2019, 11, 10000, 600000,  1930000, 5, 'aktif',     '1003', FALSE),
  (4,  'Dhimas Bagus P.',    2019, 11, 20000, 1200000, 1930000, 1, 'aktif',     '1004', FALSE),
  (5,  'Rafi Sinatrya',      2019, 11, 10000, 600000,  1930000, 2, 'aktif',     '1005', FALSE),
  (6,  'Yudha Setiawan',     2019, 11, 10000, 620000,  1930000, 4, 'aktif',     '1006', FALSE),
  (7,  'Pebrian W',          2019, 11, 10000, 240000,  1930000, 3, 'aktif',     '1007', FALSE),
  (8,  'Doni Aprianto',      2019, 11, 0,     0,       0,       0, 'non-aktif', '1008', FALSE),
  (9,  'Ridwan',             2019, 11, 10000, 550000,  1930000, 1, 'aktif',     '1009', FALSE),
  (10, 'Ghufron',            2019, 11, 10000, 620000,  1930000, 5, 'aktif',     '1010', FALSE),
  (11, 'Umar',               2019, 11, 10000, 550000,  1930000, 0, 'aktif',     '1011', FALSE),
  (12, 'Guntur',             2019, 11, 10000, 580000,  1930000, 2, 'aktif',     '1012', FALSE),
  (13, 'Eka M Fajar',        2019, 11, 0,     0,       0,       0, 'non-aktif', '1013', FALSE),
  (14, 'Hendra Pimen',       2020,  1, 20000, 1100000, 1780000, 0, 'aktif',     '1014', FALSE),
  (15, 'Sandi Setiawan',     2020,  6, 30000, 1800000, 1780000, 4, 'aktif',     '1015', FALSE),
  (16, 'Kurniawan',          2021,  1, 20000, 900000,  1580000, 2, 'aktif',     '1016', FALSE),
  (17, 'Lutfan',             2021,  1, 20000, 900000,  1580000, 2, 'aktif',     '1017', FALSE),
  (18, 'A''an Dofi',         2023,  2, 0,     0,       0,       1, 'non-aktif', '1018', FALSE),
  (19, 'Erdiyan Pratama',    2023,  3, 10000, 200000,  1050000, 2, 'aktif',     '1019', FALSE),
  (20, 'Nur Ahmad Mursyid',  2023,  3, 10000, 200000,  1050000, 4, 'aktif',     '1020', FALSE),
  (21, 'Didik Dwi W.',       2023,  3, 10000, 200000,  1050000, 1, 'aktif',     '1021', FALSE),
  (22, 'Sano / Tyosano',     2023,  7, 10000, 200000,  1050000, 1, 'aktif',     '1022', FALSE),
  (23, 'Emas Perwira',       2023,  7, 10000, 180000,  1050000, 1, 'aktif',     '1023', FALSE),
  (24, 'Agus Setyawan',      2023,  9, 10000, 200000,  1050000, 2, 'aktif',     '1024', FALSE);

-- ─── 6. DATA PINJAMAN ───
-- Pinjaman yang MASIH BERJALAN (per 15 Mei 2026)

INSERT INTO loans (member_no, amount, tenor, status, start_date, sisa, last_pay) VALUES
  (16, 5500000, 6, 'cicil', '2023-08-30', 1500000, '2023-11-29'),  -- Kurniawan
  (21, 3300000, 6, 'cicil', '2024-05-01',  600000, '2026-04-20'),  -- Didik
  (17, 2200000, 3, 'cicil', '2024-06-01', 2200000, NULL),          -- Lutfan
  (24, 1100000, 6, 'cicil', '2025-03-06', 1100000, NULL),          -- Agus
  (12, 5500000, 6, 'cicil', '2025-03-10', 1500000, '2025-08-11'),  -- Guntur
  (22, 3150000, 5, 'cicil', '2025-04-08', 3150000, NULL),          -- Sano
  (15, 4400000, 4, 'cicil', '2025-10-31', 1100000, '2026-01-31'),  -- Sandi
  (11, 3300000, 6, 'cicil', '2025-12-23', 1300000, '2026-04-25'),  -- Umar
  (6,  6300000, 6, 'cicil', '2026-01-03', 2000000, '2026-05-08'),  -- Yudha
  (3,  9300000, 6, 'cicil', '2026-03-11', 9300000, NULL),          -- Alif
  (10, 6300000, 6, 'baru',  '2026-05-15', 6300000, NULL);          -- Ghufron

-- Pinjaman yang SUDAH LUNAS (untuk hitung level anggota)

INSERT INTO loans (member_no, amount, tenor, status, start_date, sisa, lunas_date) VALUES
  (16, 2750000, 3, 'lunas', '2021-11-01', 0, '2022-02-01'),
  (16, 2250000, 3, 'lunas', '2022-01-01', 0, '2022-04-01'),
  (18, 4950000, 6, 'lunas', '2023-02-01', 0, '2025-12-04'),
  (20, 2100000, 3, 'lunas', '2023-10-01', 0, '2024-01-16'),
  (17, 3300000, 3, 'lunas', '2023-11-01', 0, '2024-02-13'),
  (12, 3300000, 3, 'lunas', '2024-02-01', 0, '2024-05-09'),
  (19, 3300000, 3, 'lunas', '2024-02-01', 0, '2024-05-03'),
  (24, 2100000, 3, 'lunas', '2024-06-01', 0, '2024-09-15'),
  (5,  3850000, 3, 'lunas', '2023-12-01', 0, '2024-03-27'),
  (3,  3300000, 3, 'lunas', '2024-09-01', 0, '2024-12-24'),
  (22, 4235000, 3, 'lunas', '2024-01-01', 0, '2024-04-19'),
  (4,  3300000, 3, 'lunas', '2023-11-01', 0, '2024-02-27'),
  (15, 4400000, 3, 'lunas', '2024-04-01', 0, '2024-07-02'),
  (7,  4400000, 3, 'lunas', '2024-07-01', 0, '2024-10-11'),
  (20, 1100000, 3, 'lunas', '2024-06-01', 0, '2024-09-11'),
  (1,  1650000, 3, 'lunas', '2024-02-01', 0, '2024-05-29'),
  (6,  6000000, 3, 'lunas', '2024-07-01', 0, '2024-10-07'),
  (5,  3500000, 3, 'lunas', '2024-08-30', 0, '2025-05-04'),
  (15, 2200000, 3, 'lunas', '2024-08-22', 0, '2024-11-03'),
  (24, 1100000, 3, 'lunas', '2024-09-26', 0, '2025-02-03'),
  (20, 1100000, 3, 'lunas', '2024-09-28', 0, '2025-03-15'),
  (10, 1100000, 3, 'lunas', '2024-11-11', 0, '2024-12-27'),
  (6,  4400000, 3, 'lunas', '2024-12-17', 0, '2025-03-01'),
  (7,  4400000, 3, 'lunas', '2024-12-22', 0, '2025-12-31'),
  (10, 2500000, 6, 'lunas', '2025-01-02', 0, '2025-05-04'),
  (6,  6300000, 6, 'lunas', '2025-03-29', 0, '2025-05-28'),
  (3,  10500000,6, 'lunas', '2025-03-27', 0, '2026-01-30'),
  (20, 1575000, 3, 'lunas', '2025-03-27', 0, '2026-01-30'),
  (10, 6300000, 6, 'lunas', '2025-05-10', 0, '2026-05-01'),
  (19, 3150000, 3, 'lunas', '2025-06-15', 0, '2025-10-01'),
  (23, 2000000, 3, 'lunas', '2025-05-28', 0, '2025-09-04'),
  (6,  5250000, 6, 'lunas', '2025-06-24', 0, '2025-11-15'),
  (1,  2000000, 3, 'lunas', '2022-01-01', 0, '2022-04-01'),
  (2,  1000000, 3, 'lunas', '2020-01-01', 0, '2020-04-01'),
  (9,  5003339, 3, 'lunas', '2021-11-01', 0, '2022-02-01'),
  (12, 3000000, 3, 'lunas', '2020-01-01', 0, '2020-04-01'),
  (15, 3000000, 3, 'lunas', '2021-11-01', 0, '2022-02-01'),
  (17, 3000000, 3, 'lunas', '2022-01-01', 0, '2022-04-01'),
  (21, 2000133, 3, 'lunas', '2023-05-01', 0, '2023-08-01'),
  (3,  4717779, 3, 'lunas', '2021-01-01', 0, '2021-04-01'),
  (3,  5301249, 3, 'lunas', '2022-01-01', 0, '2022-04-01'),
  (3,  1000225, 3, 'lunas', '2023-05-01', 0, '2023-08-01'),
  (7,  2000000, 1, 'lunas', '2021-11-01', 0, '2021-12-01'),
  (10, 3000000, 3, 'lunas', '2019-12-01', 0, '2020-03-01'),
  (10, 4000000, 3, 'lunas', '2021-11-01', 0, '2022-02-01');

-- ─── 7. REKENING KOPERASI ───
-- Ganti nama & nomor rekening sesuai kondisi asli.
-- Saldo awal isi 0 dulu, nanti update manual lewat aplikasi.

INSERT INTO banks (name, type, holder, acc_no, balance, color) VALUES
  ('BRI',        'bank', 'Koperasi The Power 55', '-', 0, '#003D7A'),
  ('Kas Tunai',  'cash', 'Bendahara',             '-', 0, '#22C55E');

-- ─── 8. AKTIFKAN REALTIME ───
ALTER PUBLICATION supabase_realtime ADD TABLE applications;
ALTER PUBLICATION supabase_realtime ADD TABLE votes;
ALTER PUBLICATION supabase_realtime ADD TABLE loans;
ALTER PUBLICATION supabase_realtime ADD TABLE banks;
ALTER PUBLICATION supabase_realtime ADD TABLE transactions;
ALTER PUBLICATION supabase_realtime ADD TABLE members;

-- ═══════════════════════════════════════════════════════════
-- SELESAI. Cek: Table Editor → harus ada 6 tabel terisi.
-- ═══════════════════════════════════════════════════════════
